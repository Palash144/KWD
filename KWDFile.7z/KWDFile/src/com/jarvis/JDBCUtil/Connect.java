/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jarvis.JDBCUtil;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author plambh01
 */
public class Connect {
    
    public static Connection getConnection(String username,String password,String environment){
        try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  

			//step2 create  the connection object  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@//UORC398N.DEV.BSCAL.LOCAL:12521/"+environment, username,password);  
                        return con;
        }
        catch(Exception e){
            e.printStackTrace();
            return null;
        }
        
    }
}
