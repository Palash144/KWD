import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Conx {

	SimpleDateFormat sd=new SimpleDateFormat("yyyyMMdd");
	private String file_name="mms-"+sd.format(new Date());
	private ResultSet rs=null;
	private final String FILENAME ="C:\\Users\\plambh01\\Documents\\"+file_name+".kwd";
	private String fname="Harry";
	private String lname="Stephen";
	GroupDetail gd=new GroupDetail();

	public ResultSet getData() {
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  

			//step2 create  the connection object  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@//UORC398N.DEV.BSCAL.LOCAL:12521/FACN51A", "syplambh01", "Palash@2332151");  

			//step3 create the statement object  
			Statement stmt=con.createStatement();  

			//step4 execute query  
			rs=stmt.executeQuery("SELECT GRGR_ID,to_char(GRGR.GRGR_ORIG_EFF_DT,'dd/mm/yyyy'),SGSG.SGSG_ID,CSPI.CSCS_ID,to_char(SGSG.SGSG_ORIG_EFF_DT,'dd/mm/yyyy') ,to_char(CSPI.CSPI_EFF_DT,'dd/mm/yyyy'),CSPI.CSPD_CAT, CSPI.CSPI_ID FROM FC_CMC_GRGR_GROUP GRGR,FC_CMC_SGSG_SUB_GROUP SGSG,FC_CMC_CSPI_CS_PLAN CSPI WHERE GRGR.GRGR_CK=SGSG.GRGR_CK AND GRGR.GRGR_CK=CSPI.GRGR_CK AND GRGR_ID='PSFTS18'");  
			//while(rs.next())  
			//System.out.println("@pRECTYPE="+"\""+ rs.getString(1)+"\""+ rs.getString(2)+"\""+ rs.getString(3)+"\""+ rs.getString(4)+"\""+ rs.getString(5)+"\""+ rs.getString(6)+"\""+ rs.getString(7)+"\""+ rs.getString(8)+"\"");  
			return rs;

			//step5 close the connection object  
			//con.close();  
		}
		catch(Exception e)
		{ 
			System.out.println(e);
			return rs;
		}


	}

	public void fileio() throws SQLException {

		
		
		
		while(rs.next()){
			gd.setGrgr_id(rs.getString(1));
			gd.setGrgr_orig_eff_dt(rs.getString(2));
			gd.setSgsg_id(rs.getString(3)) ;        
			gd.setCscs_id(rs.getString(4) );      
			gd.setSgsg_orig_eff_dt(rs.getString(5));
			gd.setCspi_eff_dt( rs.getString(6));   
			gd.setCspd_cat( rs.getString(7)); 
			gd.setCspi_id(rs.getString(8));
		}

		BufferedWriter bw = null;
		FileWriter fw = null;
		String fl="@pRECTYPE=\"SBSB\",@pSBSB_FAM_UPDATE_CD=\"AP\",@pSBSB_ID=\"\",@pGRGR_ID=\""+gd.getGrgr_id()+"\",@pSBSB_LAST_NAME=\""+lname+"\""+",@pSBSB_FIRST_NAME="+"\""+fname+"\""+",@pSBSB_MID_INIT=\"\""+",@pSBSB_TITLE=\"\",@pSBSB_ORIG_EFF_DT=\""+gd.getGrgr_orig_eff_dt()+"\",@pSBSB_MCTR_STS=\"AC\",@pSBSB_MCTR_VIP=\"\",@pSBSB_PAY_CL_METH=\"S\",@pSBSB_EMPLOY_ID=\"\",@pSBSB_HIRE_DT=\"\",@pSBSB_RETIRE_DT=\"\",@pSBSB_CONV_DT=\"\",@pSBSB_FI=\"A\",@pSBAD_TYPE_HOME=\"H\",@pSBAD_TYPE_MAIL=\"H\",@pSBAD_TYPE_WORK=\"\",@pSBSB_SIG_DT=\"\",@pSBSB_RECD_DT=\"\"";
		String sl="@pRECTYPE=\"SBAD\",@pSBAD_UPDATE_CD=\"AP\",@pSBAD_TYPE=\"H\",@pADDR1=\"130 Elm St.\",@pADDR2=\"\",@pADDR3=\"\",@pCITY=\"TRABUCO CANYON\",@pSTATE=\"CA\",@pZIP=\"92678\",@pPHONE=\"2813732101\",@pPHONE_EXT=\"\",@pFAX=\"2813732101\",@pFAX_EXT=\"\",@pEMAIL=\"NO_NAME@BSC.COM\"";
		String tl="@pRECTYPE=\"SBSG\",@pSBSG_UPDATE_CD=\"AP\",@pSBSG_EFF_DT=\""+gd.getSgsg_orig_eff_dt()+"\",@pSGSG_ID=\""+gd.getSgsg_id()+"\"";
		String frl="@pRECTYPE=\"SBCS\",@pSBCS_UPDATE_CD=\"AP\",@pSBCS_EFF_DT=\""+gd.getCspi_eff_dt()+"\",@pCSCS_ID=\""+gd.getCscs_id()+"\"";
		String fvl="@pRECTYPE=\"SBEL\",@pSBEL_UPDATE_CD=\"EN\",@pSBEL_ELIG_TYPE=\"SL\",@pSBEL_EFF_DT=\"01/01/2018\",@pCSPD_CAT=\""+gd.getCspd_cat()+"\",@pCSPI_ID=\""+gd.getCspi_id()+"\",@pSBEL_FI=\"A\"";
		String sxl="@pRECTYPE=\"MEME\",@pMEME_UPDATE_CD=\"AP\",@pMEME_REL=\"M\",@pMEME_LAST_NAME=\""+lname+"\",@pMEME_FIRST_NAME=\""+fname+"\",@pMEME_MID_INIT=\",@pMEME_TITLE=\"\",@pMEME_ORIG_EFF_DT=\"01/01/2018\",@pMEME_SSN=\"317875509\",@pMEME_SEX=\"M\",@pMEME_BIRTH_DT=\"06/29/1979\",@pMEME_WRK_PHONE=\"\",@pMEME_CELL_PHONE=\"\",@pMEME_MCTR_STS=\"\",@pMEME_MCTR_LANG=\"\",@pMEME_RECORD_NO=\"\",@pMEME_MARITAL_STATUS=\"M\",@pMEME_HICN=\"\",@pMEME_MEDCD_NO=\"\",@pMEME_FAM_LINK_ID=\"\",@pSBAD_TYPE_HOME=\"H\",@pSBAD_TYPE_MAIL=\"H\",@pSBAD_TYPE_WORK=\"H\"";
		try {

			String content = fl+"\n"+sl+"\n"+tl+"\n"+frl+"\n"+fvl+"\n"+sxl;
			fw = new FileWriter(FILENAME);
			bw = new BufferedWriter(fw);
			bw.write(content);

			System.out.println("Done");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
	}
	public static void main(String[] args) {
		Conx c=new Conx();
		c.getData();
		
		SimpleDateFormat sd=new SimpleDateFormat("yyyyMMdd");
		//sd.format(new Date());
		System.out.println(sd.format(new Date()));
		Person per=new Person();
		try {
			c.fileio();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
