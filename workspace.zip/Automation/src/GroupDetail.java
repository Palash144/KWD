
public class GroupDetail {

	private String grgr_id ;
	private String grgr_orig_eff_dt;
	private String sgsg_id;
	private String cscs_id;
	private String sgsg_orig_eff_dt;
	private String cspi_eff_dt;
	private String cspd_cat;
	private String cspi_id;
	
	
	public String getGrgr_id() {
		return grgr_id;
	}
	public void setGrgr_id(String grgr_id) {
		this.grgr_id = grgr_id;
	}
	public String getGrgr_orig_eff_dt() {
		return grgr_orig_eff_dt;
	}
	public void setGrgr_orig_eff_dt(String grgr_orig_eff_dt) {
		this.grgr_orig_eff_dt = grgr_orig_eff_dt;
	}
	public String getSgsg_id() {
		return sgsg_id;
	}
	public void setSgsg_id(String sgsg_id) {
		this.sgsg_id = sgsg_id;
	}
	public String getCscs_id() {
		return cscs_id;
	}
	public void setCscs_id(String cscs_id) {
		this.cscs_id = cscs_id;
	}
	public String getSgsg_orig_eff_dt() {
		return sgsg_orig_eff_dt;
	}
	public void setSgsg_orig_eff_dt(String sgsg_orig_eff_dt) {
		this.sgsg_orig_eff_dt = sgsg_orig_eff_dt;
	}
	public String getCspi_eff_dt() {
		return cspi_eff_dt;
	}
	public void setCspi_eff_dt(String cspi_eff_dt) {
		this.cspi_eff_dt = cspi_eff_dt;
	}
	public String getCspd_cat() {
		return cspd_cat;
	}
	public void setCspd_cat(String cspd_cat) {
		this.cspd_cat = cspd_cat;
	}
	public String getCspi_id() {
		return cspi_id;
	}
	public void setCspi_id(String cspi_id) {
		this.cspi_id = cspi_id;
	}
	
	
	
}
