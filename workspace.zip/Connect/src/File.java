import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

class File {
	private static final String FILENAME ="C:\\Users\\plambh01\\Documents\\a.txt";
	private static String fname="Harry";
	private static String lname="Stephen";
	
	public void fileio() throws SQLException {
	
			Connect co=new Connect();
			
			ResultSet rs=co.Conn();
		
			rs.getString(1);
			
			BufferedWriter bw = null;
			FileWriter fw = null;
			String fl="@pRECTYPE=\"SBSB\",@pSBSB_FAM_UPDATE_CD=\"AP\",@pSBSB_ID=\"\",@pGRGR_ID=\"W1111223\",@pSBSB_LAST_NAME=\""+lname+"\""+",@pSBSB_FIRST_NAME="+"\""+fname+"\""+",@pSBSB_MID_INIT=\"\""+",@pSBSB_TITLE=\"\",@pSBSB_ORIG_EFF_DT=\"01/01/2018\",@pSBSB_MCTR_STS=\"AC\",@pSBSB_MCTR_VIP=\"\",@pSBSB_PAY_CL_METH=\"S\",@pSBSB_EMPLOY_ID=\"\",@pSBSB_HIRE_DT=\"\",@pSBSB_RETIRE_DT=\"\",@pSBSB_CONV_DT=\"\",@pSBSB_FI=\"A\",@pSBAD_TYPE_HOME=\"H\",@pSBAD_TYPE_MAIL=\"H\",@pSBAD_TYPE_WORK=\"\",@pSBSB_SIG_DT=\"\",@pSBSB_RECD_DT=\"\"";
			String sl="@pRECTYPE=\"SBAD\",@pSBAD_UPDATE_CD=\"AP\",@pSBAD_TYPE=\"H\",@pADDR1=\"130 Elm St.\",@pADDR2=\"\",@pADDR3=\"\",@pCITY=\"TRABUCO CANYON\",@pSTATE=\"CA\",@pZIP=\"92678\",@pPHONE=\"2813732101\",@pPHONE_EXT=\"\",@pFAX=\"2813732101\",@pFAX_EXT=\"\",@pEMAIL=\"NO_NAME@BSC.COM\"";
			String tl="@pRECTYPE=\"SBSG\",@pSBSG_UPDATE_CD=\"AP\",@pSBSG_EFF_DT=\"01/01/2018\",@pSGSG_ID=\"1000\"";
			String frl="@pRECTYPE=\"SBCS\",@pSBCS_UPDATE_CD=\"AP\",@pSBCS_EFF_DT=\"01/01/2018\",@pCSCS_ID=\"1000\"";
			try {

				String content = fl+"\n"+sl+"\n"+tl+"\n"+frl;
				fw = new FileWriter(FILENAME);
				bw = new BufferedWriter(fw);
				bw.write(content);

				System.out.println("Done");

			} catch (IOException e) {

				e.printStackTrace();

			} finally {

				try {

					if (bw != null)
						bw.close();

					if (fw != null)
						fw.close();

				} catch (IOException ex) {

					ex.printStackTrace();

				}

			}

		}

	}


