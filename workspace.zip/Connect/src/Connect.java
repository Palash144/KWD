import java.sql.*;  

class Connect{
	public ResultSet rs;
	public ResultSet Conn() {

		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  

			//step2 create  the connection object  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@//UORC398N.DEV.BSCAL.LOCAL:12521/FACN51A", "syplambh01", "Palash@2332151");  

			//step3 create the statement object  
			Statement stmt=con.createStatement();  

			//step4 execute query  
			rs=stmt.executeQuery("SELECT GRGR_ID,GRGR.GRGR_ORIG_EFF_DT,SGSG.SGSG_ID,CSPI.CSCS_ID, SGSG.SGSG_ORIG_EFF_DT, CSPI.CSPI_EFF_DT, CSPI.CSPD_CAT, CSPI.CSPI_ID FROM FC_CMC_GRGR_GROUP GRGR,FC_CMC_SGSG_SUB_GROUP SGSG,FC_CMC_CSPI_CS_PLAN CSPI WHERE GRGR.GRGR_CK=SGSG.GRGR_CK AND GRGR.GRGR_CK=CSPI.GRGR_CK AND GRGR_ID='PSFTS007'");  
			while(rs.next())  
				System.out.println("@pRECTYPE="+"\""+ rs.getString(1)+"\""+ rs.getString(2)+"\""+ rs.getString(3)+"\""+ rs.getString(4)+"\""+ rs.getString(5)+"\""+ rs.getString(6)+"\""+ rs.getString(7)+"\""+ rs.getString(8)+"\"");  
				

			//step5 close the connection object  
			con.close();  
			return rs;
		}
		catch(Exception e)
		{ 
			System.out.println(e);
			return rs;
		}
	}
}

